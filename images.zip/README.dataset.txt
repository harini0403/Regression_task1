# truck > dataset1
https://universe.roboflow.com/truckdetection-nlbvl/truck-p675h

Provided by a Roboflow user
License: CC BY 4.0

